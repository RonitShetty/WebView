package com.example.experiment05;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class StaticHtmlActivity extends AppCompatActivity {

    private WebView webViewStatic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_static_html);

        webViewStatic = findViewById(R.id.webview_static);

        // Enable JavaScript
        webViewStatic.getSettings().setJavaScriptEnabled(true);

        // Load static HTML content
        String staticHtml = "<html><body><h1>Welcome to NMIMS</h1><p>It's a static web HTML content.</p></body></html>";
        webViewStatic.loadData(staticHtml, "text/html", "UTF-8");

        // Ensure links open within the WebView
        webViewStatic.setWebViewClient(new WebViewClient());
    }
}