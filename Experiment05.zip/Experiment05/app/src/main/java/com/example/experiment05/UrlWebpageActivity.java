package com.example.experiment05;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class UrlWebpageActivity extends AppCompatActivity {

    private EditText urlInput;
    private Button buttonSubmit;
    private WebView webViewDynamic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_url_webpage);

        urlInput = findViewById(R.id.url_input);
        buttonSubmit = findViewById(R.id.button_submit);
        webViewDynamic = findViewById(R.id.webview_dynamic);

        // Enable JavaScript
        webViewDynamic.getSettings().setJavaScriptEnabled(true);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlInput.getText().toString().trim();

                // Validate input
                if (url.isEmpty()) {
                    showAlertDialog("Invalid Input", "Please enter a website URL.");
                } else if (!isValidUrl(url)) {
                    showAlertDialog("Invalid URL", "The URL entered is not valid. Please enter a valid URL starting with http:// or https://.");
                } else {
                    // Prepend "http://" if not present
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "http://" + url;
                    }
                    webViewDynamic.loadUrl(url);

                    // Ensure links open within the WebView
                    webViewDynamic.setWebViewClient(new WebViewClient());
                }
            }
        });
    }

    // Method to validate the URL format
    private boolean isValidUrl(String url) {
        return android.util.Patterns.WEB_URL.matcher(url).matches();
    }

    // Method to show an AlertDialog with a custom design
    private void showAlertDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .setIcon(android.R.drawable.ic_dialog_alert);

        // Customize the dialog appearance
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        // Optionally customize button appearance or dialog window
        Button positiveButton = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (positiveButton != null) {
            positiveButton.setTextColor(getResources().getColor(android.R.color.holo_red_light));
        }
    }
}